﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Tipshare
{
    public class SaveInternalData
    {
        public string Name, EmployeeID;
        public DateTime DateOfData;
        public double SuggestedAmount, AdjustedAmount;

        public SaveInternalData(string Name, string EmployeeID, DateTime DateOfData, double SuggestedAmount, double AdjustedAmount)
        {
            this.Name = Name;
            this.EmployeeID = EmployeeID;
            this.DateOfData = DateOfData;
            this.SuggestedAmount = SuggestedAmount;
            this.AdjustedAmount = AdjustedAmount;
        }
    }

    public class SaveUploadData
    {
        public string SSN;
        public DateTime DateOfData;
        public double AdjustedAmount;

        public SaveUploadData(string SSN, DateTime DateOfData, double AdjustedAmount)
        {
            this.SSN = SSN;
            this.DateOfData = DateOfData;
            this.AdjustedAmount = AdjustedAmount;
        }
    }

    public class Entry : IComparable
    {
        public string Name, EmployeeID;
        public double SuggestedAmount, AdjustedAmount, Hours;
        public Entry(string Name, string EmployeeID, double SuggestedAmount, double AdjustedAmount, double Hours)
        {
            this.Name = Name;
            this.EmployeeID = EmployeeID;
            this.SuggestedAmount = SuggestedAmount;
            this.AdjustedAmount = AdjustedAmount;
            this.Hours = Hours;
        }

        public int CompareTo(object obj)
        {
            if (obj is Entry)
                return this.Name.CompareTo(((Entry)obj).Name);
            else
                return 0;
        }
    }
    
    public class Shift
    {
        public string Name, EmployeeID, JobCode;
        public DateTime ClockIn, ClockOut;
        public Shift(string Name, string EmployeeID, string JobCode, DateTime ClockIn, DateTime ClockOut)
        {
            this.Name = Name;
            this.EmployeeID = EmployeeID;
            this.JobCode = JobCode;
            this.ClockIn = ClockIn;
            this.ClockOut = ClockOut;
        }

        public double Hours
        {
            get
            {
                return (ClockOut - ClockIn).TotalHours;
            }
        }
    }

    public class ThreadArgs
    {
        public DateTime DateToCheck;
        public bool CheckForSavedData;
        public ThreadArgs(DateTime DateToCheck, bool CheckForSavedData)
        {
            this.DateToCheck = DateToCheck;
            this.CheckForSavedData = CheckForSavedData;
        }
    }

    public class Ticket
    {
        public string EmployeeID;
        public DateTime ServeDate;
        public double Amount;
        public Ticket(string EmployeeID, DateTime ServeDate, double Amount)
        {
            this.EmployeeID = EmployeeID;
            this.ServeDate = ServeDate;
            this.Amount = Amount;
        }
    }

    public class Employee
    {
        public string Name, SSN, EmployeeID;

        public Employee(string Name, string EmployeeID, string SSN)
            : this(Name, EmployeeID)
        {
            this.SSN = SSN;
        }

        public Employee(string Name, string EmployeeID)
        {
            this.Name = Name;
            this.EmployeeID = EmployeeID;
        }
    }

    public class Colors
    {
        public static Color BackGood = Color.Green;
        public static Color BackBad = Color.Red;
        public static Color FontGood = Color.White;
        public static Color FontBad = Color.White;
    }
}
