﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StatRetrieval.Shared.Common.DataContracts
{
    public class EmployeeData
    {
        public string SSN { get; set; }
        public string Name { get; set; }
        public string EmployeeId { get; set; }
    }
}
